/**
 * 
 */
/**
 * @author MSIS
 *
 */
module demo1 {
	requires json.simple;
}