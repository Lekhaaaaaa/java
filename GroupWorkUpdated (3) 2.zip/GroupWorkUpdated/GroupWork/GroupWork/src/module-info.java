module GroupWork {
	requires org.apache.logging.log4j;
	requires java.sql;
	//requires java.servlet;
	requires java.net.http;
	requires mongo.java.driver;
	

}