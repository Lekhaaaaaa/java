package mongodb;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import CustomException.IdNotFound;
import team1.Employee;
import team1.EmployeeManagement;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class MongoDBDatabase implements EmployeeManagement {

    private final MongoClient mongoClient;
    private final MongoDatabase database;
    private final MongoCollection<Document> employeeCollection;

    public MongoDBDatabase() {
        // Establish connection to MongoDB
        mongoClient = MongoClients.create("mongodb://localhost:27017");
        database = mongoClient.getDatabase("employee_db");
        employeeCollection = database.getCollection("employees");
    }

    @Override
    public void addEmployee(Employee employee) {
        // Create a document representing the employee
        Document employeeDoc = new Document("employee_id", employee.getId())
                                .append("employee_name", employee.getName())
                                .append("employee_Sal", employee.getSalary())
                                .append("employee_des", calculateDesignation(employee.getSalary()));

        // Insert the document into the collection
        employeeCollection.insertOne(employeeDoc);
        System.out.println("Employee added successfully to the database");
    }

    @Override
    public void deleteEmployee(int employeeId) {
        // Delete the document with the specified employee_id
        employeeCollection.deleteOne(new Document("employee_id", employeeId));
        System.out.println("Employee deleted successfully from the database");
    }

    /*@Override
    public void updateEmployee(int employeeId, Employee newEmployee) throws IdNotFound {
        // Update the document with the specified employee_id
        Document updatedEmployee = new Document("$set",
                new Document("employee_name", newEmployee.getName())
                        .append("employee_Sal", newEmployee.getSalary())
                        .append("employee_des", calculateDesignation(newEmployee.getSalary())));
        employeeCollection.updateOne(new Document("employee_id", employeeId), updatedEmployee);
        System.out.println("Employee updated successfully in the database");
    }

    @Override
    public List<Employee> listEmployees(boolean includePersonalDetails) {
        // Retrieve all documents from the collection
        List<Employee> employees = new ArrayList<>();
        for (Document doc : employeeCollection.find()) {
            Employee employee = new Employee(doc.getInteger("employee_id"),
                                              doc.getString("employee_name"),
                                              doc.getDouble("employee_Sal"));
            employees.add(employee);
        }
        return employees;
    }*/

    // Helper method to calculate employee designation
    private String calculateDesignation(double salary) {
        // Logic to determine the designation based on the salary
        if (salary >= 80000) {
            return "Senior Manager";
        } else if (salary >= 60000) {
            return "Manager";
        } else if (salary >= 40000) {
            return "Team Lead";
        } else {
            return "Employee";
        }
    }
}
