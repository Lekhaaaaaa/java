package CustomException;

public class IdNotFound extends Exception{
	public IdNotFound (String string) {
		 super(string);
	  }
}
