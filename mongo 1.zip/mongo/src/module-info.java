/**
 * 
 */
/**
 * @author MSIS
 *
 */
module mongo {
	requires mongo.java.driver;
}